const columns = [
{"title":"id","dataIndex":"id","index":0,"align":"left","fixed":false},
{"title":"店铺游戏ID","dataIndex":"gameId","index":1,"align":"left","fixed":false},
{"title":"店铺游戏名称","dataIndex":"gameName","index":2,"align":"left","fixed":false},
{"title":"游戏名称","dataIndex":"flGameName","index":3,"align":"left","fixed":false},
{"title":"操作","dataIndex":"operation"}
];
export default columns;
