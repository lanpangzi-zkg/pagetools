const columns = [
{"title":"id","dataIndex":"id","index":0,"align":"left","fixed":false},
{"title":"column1","dataIndex":"dataIndex1","index":1,"align":"left","fixed":false},
{"title":"column2","dataIndex":"dataIndex2","index":2,"align":"left","fixed":false},
{"title":"column3","dataIndex":"dataIndex3","index":3,"align":"left","fixed":false},
{"title":"column4","dataIndex":"dataIndex4","index":4,"align":"left","fixed":false}
];
export default columns;
